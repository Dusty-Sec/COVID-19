package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class News extends AppCompatActivity {
    String tempholder_n,url,t_jpg,t1_jpg,t2_jpg,t3_jpg,t4_jpg;
    String ct,ct_1,ct_2,ct_3,ct_4,t_title,t1_title,t2_title,t3_title,t4_title;
    TextView txt_n,txt1_n,txt2_n,txt3_n,txt_4,newa;
    AdView ad7;
    ImageView imageview,imageview1,imageview2,imageview3,imageview4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        tempholder_n = getIntent().getStringExtra("Listv");
        txt_n = findViewById(R.id.txt_n);
        txt1_n = findViewById(R.id.txt1_n);
        txt2_n = findViewById(R.id.txt2_n);
        txt3_n = findViewById(R.id.txt3_n);
        txt_4 = findViewById(R.id.txt4_n);
        newa = findViewById(R.id.newa);
        newa.setText(tempholder_n + " News");
        imageview = findViewById(R.id.img_n);
        imageview1 = findViewById(R.id.imageView1);
        imageview2 = findViewById(R.id.imageView2);
        imageview3 = findViewById(R.id.imageView3);
        imageview4 = findViewById(R.id.imageView4);
        ad7 = findViewById(R.id.ad7);

    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isNetworkAvailable()) {
            AsyncTask<Void, Void, Void> execute = new duit().execute();
            AdRequest adreq = new AdRequest.Builder().build();
            ad7.loadAd(adreq);
            txt_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct = url + ct;
                        intent.putExtra("newsa",ct);
                        intent.putExtra("newsas",t_jpg);
                        intent.putExtra("newsasa",t_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            imageview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct = url + ct;
                        intent.putExtra("newsa",ct);
                        intent.putExtra("newsas",t_jpg);
                        intent.putExtra("newsasa",t_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt1_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_1 = url + ct_1;
                        intent.putExtra("newsa",ct_1);
                        intent.putExtra("newsas",t1_jpg);
                        intent.putExtra("newsasa",t1_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            imageview1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_1 = url + ct_1;
                        intent.putExtra("newsa",ct_1);
                        intent.putExtra("newsas",t1_jpg);
                        intent.putExtra("newsasa",t1_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt2_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_2 = url + ct_2;
                        intent.putExtra("newsa",ct_2);
                        intent.putExtra("newsas",t2_jpg);
                        intent.putExtra("newsasa",t2_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            imageview2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_2 = url + ct_2;
                        intent.putExtra("newsa",ct_2);
                        intent.putExtra("newsas",t2_jpg);
                        intent.putExtra("newsasa",t2_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt3_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_3 = url + ct_3;
                        intent.putExtra("newsa",ct_3);
                        intent.putExtra("newsas",t3_jpg);
                        intent.putExtra("newsasa",t3_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            imageview3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_3 = url + ct_3;
                        intent.putExtra("newsa",ct_3);
                        intent.putExtra("newsas",t3_jpg);
                        intent.putExtra("newsasa",t3_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt_4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_4 = url + ct_4;
                        intent.putExtra("newsa",ct_4);
                        intent.putExtra("newsas",t4_jpg);
                        intent.putExtra("newsasa",t4_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            imageview4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Intent intent = new Intent(News.this,Art.class);
                        ct_4 = url + ct_4;
                        intent.putExtra("newsa",ct_4);
                        intent.putExtra("newsas",t4_jpg);
                        intent.putExtra("newsasa",t4_title);
                        startActivity(intent);
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }
        else{
            Toast.makeText(this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
            txt_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Toast.makeText(News.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt1_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Toast.makeText(News.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt2_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Toast.makeText(News.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt3_n.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Toast.makeText(News.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();

                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
            txt_4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try{
                        Toast.makeText(News.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
                    }
                    catch (Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }

    }
    private boolean isNetworkAvailable()
    {

        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();

    }
    @SuppressLint("StaticFieldLeak")
    public class duit extends AsyncTask<Void, Void, Void> {
        Elements title,title1,title2,title3,update_m;
        Elements tot,tot1,tot2,tot3,tot_m,sp;

        @Override
        protected Void doInBackground(Void... params) {
            try {
                url = "https://timesofindia.indiatimes.com/india/" + tempholder_n.toLowerCase();
                Document doc = Jsoup.connect(url).get();
                title = doc.select("ul#content");
                ct = title.select("a").attr("href");
                title1 = title.select("li");
                t_jpg = title.select("img").attr("data-src");
                t_title = title.select("img").attr("alt");
                Element row1 = title1.get(1);
                t1_title = row1.select("a").attr("title");
                t1_jpg = row1.select("span.fb").attr("data-social-img");
                ct_1 = row1.select("a").attr("href");
                Element row2 = title1.get(2);
                t2_title = row2.select("a").attr("title");
                t2_jpg = row2.select("span.fb").attr("data-social-img");
                ct_2 = row2.select("a").attr("href");
                Element row3 = title1.get(3);
                t3_title = row3.select("a").attr("title");
                t3_jpg = row3.select("span.fb").attr("data-social-img");
                ct_3 = row3.select("a").attr("href");
                Element row4 = title1.get(4);
                t4_title = row4.select("a").attr("title");
                t4_jpg = row4.select("span.fb").attr("data-social-img");
                ct_4 = row4.select("a").attr("href");


            }
            catch (Exception e){
                e.printStackTrace();
            }

            return null;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            txt_n.setText(t_title);
            txt1_n.setText(t1_title);

            txt2_n.setText(t2_title);
            txt3_n.setText(t3_title);
            txt_4.setText(t4_title);
            Picasso.get().load(t_jpg).error(R.drawable.na).into(imageview);
            Picasso.get().load(t1_jpg).error(R.drawable.na).into(imageview1);
            Picasso.get().load(t2_jpg).error(R.drawable.na).into(imageview2);
            Picasso.get().load(t3_jpg).error(R.drawable.na).into(imageview3);
            Picasso.get().load(t4_jpg).error(R.drawable.na).into(imageview4);
        }
    }

}