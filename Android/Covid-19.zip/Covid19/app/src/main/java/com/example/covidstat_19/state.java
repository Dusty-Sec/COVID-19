package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class state extends AppCompatActivity {
    TextView textView,textView1,textView2,textView3,textView4,txt10,txt11,txt12,t;
    String tempholder;
    ProgressBar pg,pg1,pg2,pg3;
    int flag = 0;
    AdView ad5;
    ArrayAdapter<String> dis;
    Spinner spinner5;
    ArrayList<String> list ;
    int count1 = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_state);
        textView1 = findViewById(R.id.textView1);
        textView2 = findViewById(R.id.textView2);
        textView3 =  findViewById(R.id.textView3);
        textView4 =  findViewById(R.id.textView4);
        textView = findViewById(R.id.textView_t);
        txt10 = findViewById(R.id.textview19);
        txt11 = findViewById(R.id.textView20);
        txt12 = findViewById(R.id.textView21);

        t = findViewById(R.id.choose);
        pg = findViewById(R.id.progressBar);
        pg1 =  findViewById(R.id.progressBar1);
        pg2 =  findViewById(R.id.progressBar2);
        pg3=  findViewById(R.id.progressBar3);
        spinner5 = findViewById(R.id.spinner5);
        tempholder = getIntent().getStringExtra("Listviewclick");
        ad5 = findViewById(R.id.ad5);
        assert tempholder != null;
        if (!(tempholder.equals("Puducherry") || tempholder.equals("Chandigarh"))) {

            Toast.makeText(this, "Tap on the line to choose district(wait for a while)", Toast.LENGTH_SHORT).show();
        }
        else{
            spinner5.setVisibility(View.GONE);
            t.setVisibility(View.GONE);
        }

    }
    @Override
    protected void onResume() {
        super.onResume();

        if (! isNetworkAvailable())
        {
            Toast.makeText(this,"Please check your Internet"+"\n"+"Connection and Restart app.",Toast.LENGTH_LONG).show();
        }
        else {
            AsyncTask<Void, Void, Void> execute = new duit().execute();
            AdRequest adreq = new AdRequest.Builder().build();
            ad5.loadAd(adreq);
            if (!((tempholder.equals("Chandigarh")) || (tempholder.equals("Puducherry")))) {
                if (count1 != 0) {
                    Toast.makeText(this, "Please wait for a while to choose another", Toast.LENGTH_SHORT).show();
                }

                count1 += 1;
                list = new ArrayList<String>();
                dis = new ArrayAdapter<String>(this, R.layout.spinner_item, list);
                dis.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinner5.setAdapter(dis);
                spinner5.setPrompt("Choose District");

                spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                            Intent intent1 = new Intent(state.this, dist.class);
                            intent1.putExtra("district_name", list.get(position));
                            intent1.putExtra("state_name", tempholder);
                            startActivity(intent1);

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

            }
        }
    }
    private boolean isNetworkAvailable()
    {
        ConnectivityManager connectivityManager
                = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);

        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    @SuppressLint("StaticFieldLeak")
    public class duit extends AsyncTask<Void, Void, Void> {
        Elements title1,title2,title3,title4;
        String t,t1,t2,t3,t4,ti;
        @Override
        protected Void doInBackground(Void... params) {
            try {
                Document doc = Jsoup.connect("https://www.grainmart.in/news/covid-19-coronavirus-india-state-and-district-wise-tally/").get();

                title1 = doc.select("section#covid-19-table");
                title2 = title1.select("div.skgm-states");
                title2 = title2.select("div.skgm-td");

                for (int i = 0; i < (title2.size()); i+=5) {
                    /*
                    Element row = title2.get(i);
                    Elements colms = row.select("td");
                    String state_name = colms.get(1).text();
                    */
                    Element row11 = title2.get(i);
                    String state_name = row11.text();
                    if (tempholder.equals(state_name)) {
                        t = state_name;
                        Element total = title2.get(i+1);
                        String[] t = total.text().split("\\s");
                        t1 = t[0];
                        Element active = title2.get(i+3);
                        String[] a = active.text().split("\\s");
                        t2 = a[0];
                        Element cured  = title2.get(i+2);
                        String[] c = cured.text().split("\\s");
                        t3 = c[0];
                        Element demise = title2.get(i+4);
                        String[] d = demise.text().split("\\s");
                        t4 = d[0];
                        /*t1 = all[i+1];
                        t2 = all[i+3];
                        t3 = all[i+5];
                        t4 = all[i+6];
                        */
                        if (t3.contains("#")) {
                            t3 = t3.replace("#", "");
                        }
                        if (t2.contains("#")) {
                            t2 = t2.replace("#", "");
                        }
                        if (t1.contains("#")) {
                            t1 = t1.replace("#", "");
                        }
                        if (t4.contains("#")) {
                            t4 = t4.replace("#", "");
                        }
                        flag = 1;
                        break;
                    }
                }

                if (!(tempholder.equals("Puducherry") || tempholder.equals("Chandigarh")) && (flag!=0)) {
                    String temp;
                    if(tempholder.equals("Dadar Nagar Haveli")){
                        temp = "Dadra and Nagar Haveli and Daman and Diu";
                    }
                    else{
                        temp = tempholder;
                    }
                    Document doc1 = Jsoup.connect("https://www.grainmart.in/news/covid-19-coronavirus-india-state-and-district-wise-tally/").get();
                    title3 = doc1.select("section#covid-19-table");
                    title4 = title3.select("div.skgm-states");
                    for (int j = 0; j < title4.size(); j++) {
                        Element row = title4.get(j);
                        String state = row.select("span.show-district").text();
                        if (temp.equals(state)) {
                            Elements row1 = row.select("div.skgm-districts");
                            Elements cols1 = row1.select("div.skgm-td");
                            int k = 5;
                            while (k < cols1.size()) {
                                String s = cols1.get(k).text();
                                if(!(s.equals("Dadra and Nagar Haveli")))
                                    list.add(s);
                                k = k + 5;
                            }

                        }

                    }
                    dis.notifyDataSetChanged();

                }
            }
            catch (Exception e){
                e.printStackTrace();
            }

            return null;
        }


        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (flag == 1) {
                int i = Integer.parseInt(t1);
                float cal_cs = (float)(Integer.parseInt(t3))* 100/i;
                String Cal_cs = String.format("%.2f",cal_cs) + "%";
                float cal_as = (float)(Integer.parseInt(t2)) * 100 /i;
                String Cal_as = String.format("%.2f",cal_as) + "%";
                float cal_ds = (float)(Integer.parseInt(t4))* 100/i;
                String Cal_ds = String.format("%.2f",cal_ds) + "%";
                textView.setText(t);
                pg.setMax(i);
                pg.setProgress(Integer.parseInt(t3));
                textView1.setText("Cured" + '\n' + t3);
                txt10.setText(Cal_cs);
                pg1.setMax(i);
                pg1.setProgress(i);
                textView2.setText("Total" + '\n' + t1);
                pg2.setMax(i);
                pg2.setProgress(Integer.parseInt(t2));
                textView3.setText("Active" + '\n' + t2);
                txt11.setText(Cal_as);
                pg3.setMax(i);
                pg3.setProgress(Integer.parseInt(t4));
                textView4.setText("Death" + '\n' + t4);
                txt12.setText(Cal_ds);

            }
            else
            {
                spinner5.setVisibility(View.GONE);
                textView.setText(tempholder);
                textView1.setText("Cured" + '\n' + "0");
                textView2.setText("Total" + '\n' + "0");
                textView3.setText("Active" + "\n" + "0");
                textView4.setText("Death" + "\n" + "0");
                Log.i("hello1","print");
            }
        }
    }
}
