package com.example.covidstat_19;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.material.navigation.NavigationView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class MainActivity extends AppCompatActivity {
    AdView ad;
    private InterstitialAd minter;
    private AppBarConfiguration mAppBarConfiguration;
    TextView textView1,textView2,textView3,textView4,textView,textView7,txt7,txt8,txt9;
    ProgressBar pg,pg1,pg2,pg3;
    NavigationView navigationView;
    DrawerLayout drawer;
    Spinner spinner,spinner_u,spinner_n;

    static int count = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (isNetworkAvailable() && count == 0)
        {
            Toast.makeText(this,"INTERNET CONNECTED",Toast.LENGTH_LONG).show();
            count++;
        }
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            drawer = findViewById(R.id.drawer_layout);
            navigationView = findViewById(R.id.nav_view);
            textView1 =  findViewById(R.id.textView1);
            textView2 = findViewById(R.id.textView2);
            textView3 =  findViewById(R.id.textView3);
            textView4 =  findViewById(R.id.textView4);
            textView7 =  findViewById(R.id.update);
            textView =  findViewById(R.id.textView);
            txt7 = findViewById(R.id.textView7);
            txt8 = findViewById(R.id.textView17);
            txt9 = findViewById(R.id.textView18);
            pg =  findViewById(R.id.progressBar);
            pg1 = findViewById(R.id.progressBar1);
            pg2 =  findViewById(R.id.progressBar2);
            pg3 =  findViewById(R.id.progressBar3);
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.

            mAppBarConfiguration = new AppBarConfiguration.Builder(
                    R.id.nav_home)
                    .setDrawerLayout(drawer)
                    .build();
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
            NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
            NavigationUI.setupWithNavController(navigationView, navController);
            spinner = (Spinner) navigationView.getMenu().findItem(R.id.navigation_drawer_item3).getActionView();
            spinner.setPrompt("Choose State");
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.states_array, R.layout.spinner_item);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
            spinner_u = (Spinner) navigationView.getMenu().findItem(R.id.union).getActionView();
            spinner_u.setPrompt("Choose UT");
            ArrayAdapter<CharSequence> adapter_u = ArrayAdapter.createFromResource(this, R.array.union_array, R.layout.spinner_item);
            adapter_u.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner_u.setAdapter(adapter_u);
            spinner_n = (Spinner) navigationView.getMenu().findItem(R.id.news).getActionView();
            spinner_n.setPrompt("Choose state/UT");
            ArrayAdapter<CharSequence> adapter_n = ArrayAdapter.createFromResource(this, R.array.newsa, R.layout.spinner_item);
            adapter_n.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner_n.setAdapter(adapter_n);
        ad =findViewById(R.id.ad1);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        minter = new InterstitialAd(this);
        minter.setAdUnitId("ca-app-pub-5400102354887853/5985367074");
        AdRequest adreq = new AdRequest.Builder().build();
        ad.loadAd(adreq);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.precaution) {
                    Intent intent = new Intent(MainActivity.this, gallery.class);
                    startActivity(intent);
                } else if (id == R.id.helpline) {
                    Intent intent = new Intent(MainActivity.this, district.class);
                    startActivity(intent);
                }
                else if (id == R.id.gaana){
                    Intent intent = new Intent(MainActivity.this,union.class);
                    startActivity(intent);
                }
                else if(id == R.id.world){
                    Intent intent= new Intent(MainActivity.this,World.class);
                    intent.putExtra("Listclick", "Worldwide");
                    startActivity(intent);
                }
                drawer.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        }

    @Override
    protected void onResume() {
        super.onResume();
        if (isNetworkAvailable()) {
            minter.loadAd(new AdRequest.Builder().build());
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    final String item = parent.getItemAtPosition(position).toString();
                    if (position != 0) {
                        if(minter.isLoaded()){
                            minter.show();
                        }
                        else {
                            Intent intent = new Intent(MainActivity.this, state.class);
                            intent.putExtra("Listviewclick", item);
                            startActivity(intent);
                            spinner.setSelection(0);
                        }
                        minter.setAdListener(new AdListener(){


                            @Override
                            public void onAdClosed() {
                                super.onAdClosed();
                                gotoState();

                            }

                            private void gotoState() {
                                Intent intent = new Intent(MainActivity.this, state.class);
                                intent.putExtra("Listviewclick", item);
                                startActivity(intent);
                                spinner.setSelection(0);
                            }
                        });

                    }
                    drawer.closeDrawer(GravityCompat.START);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {


                }
            });
            spinner_u.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    final String item = parent.getItemAtPosition(position).toString();
                    if (position != 0) {
                        if(minter.isLoaded()){
                            minter.show();

                        }
                        else {
                            Intent intent = new Intent(MainActivity.this, state.class);
                            intent.putExtra("Listviewclick", item);
                            startActivity(intent);
                            spinner_u.setSelection(0);
                        }
                        minter.setAdListener(new AdListener(){

                            @Override
                            public void onAdClosed() {
                                super.onAdClosed();
                                gotoUnion();

                            }

                            private void gotoUnion() {
                                Intent intent = new Intent(MainActivity.this, state.class);
                                intent.putExtra("Listviewclick", item);
                                startActivity(intent);
                                spinner_u.setSelection(0);
                            }
                        });
                    }

                    drawer.closeDrawer(GravityCompat.START);


                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            spinner_n.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    final String item = parent.getItemAtPosition(position).toString();
                    if (position != 0) {
                            if(minter.isLoaded()){
                                minter.show();
                            }
                            else {
                                Intent intent = new Intent(MainActivity.this, News.class);
                                intent.putExtra("Listv", item);
                                startActivity(intent);
                                spinner_n.setSelection(0);
                            }
                            minter.setAdListener(new AdListener(){

                                @Override
                                public void onAdClosed() {
                                    super.onAdClosed();
                                    gotoNews();

                                }

                                private void gotoNews() {
                                    Intent intent = new Intent(MainActivity.this, News.class);
                                    intent.putExtra("Listv", item);
                                    startActivity(intent);
                                    spinner_n.setSelection(0);
                                }
                            });

                    }
                    drawer.closeDrawer(GravityCompat.START);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            AsyncTask<Void, Void, Void> execute = new duit().execute();
    } else {
        Toast.makeText(this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    if (position != 0) {
                        spinner.setSelection(0);
                        Toast.makeText(MainActivity.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
                    }
                    drawer.closeDrawer(GravityCompat.START);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {


                }
            });
            spinner_u.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position != 0) {
                        spinner_u.setSelection(0);
                        Toast.makeText(MainActivity.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();

                    }
                    drawer.closeDrawer(GravityCompat.START);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

    }

    }

    private boolean isNetworkAvailable()
    {

            ConnectivityManager connectivityManager
                    = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            assert connectivityManager != null;
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();

    }
    @SuppressLint("StaticFieldLeak")
    public class duit extends AsyncTask<Void, Void, Void> {
        Elements title,title1,title2,title3,update_m;
        Elements tot,tot1,tot2,tot3,tot_m,sp;
        String t,t1,t2,t3,t_m,cal_c;
        @Override
        protected Void doInBackground(Void... params) {
            try {
                Document doc = Jsoup.connect("https://www.mohfw.gov.in/").get();
                update_m = doc.select("section#site-dashboard");
                tot_m = update_m.select("div.status-update");
                title = doc.select("li.bg-blue");
                title1 = doc.select("li.bg-green");
                title2 = doc.select("li.bg-red");
                tot = title.select("strong.mob-hide");
                tot1 = title1.select("strong.mob-hide");
                tot2 = title2.select("strong.mob-hide");
                sp = tot_m.select("span");
                t = tot.get(1).text();
                String[] active = t.split("\\s");
                t = active[0];
                t_m = sp.text();
                t1 = tot1.get(1).text();
                String[] recovered = t1.split("\\s");
                t1 = recovered[0];
                t2 = tot2.get(1).text();
                String[]  demise = t2.split("\\s");
                t2 = demise[0];;


            }
            catch (Exception e){
                e.printStackTrace();
            }

            return null;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            int i = Integer.parseInt(t) + Integer.parseInt(t1) + Integer.parseInt(t2);
            float cal_c = (float)(Integer.parseInt(t1))* 100/i;
            String Cal_c = String.format("%.2f",cal_c) + "%";
            float cal_a = (float)(Integer.parseInt(t)) * 100 /i;
            String Cal_a = String.format("%.2f",cal_a) + "%";
            float cal_d = (float)(Integer.parseInt(t2))* 100/i;
            String Cal_d = String.format("%.2f",cal_d) + "%";
            pg.setMax(i);
            pg.setProgress(Integer.parseInt(t1));
            textView1.setText("Cured"+'\n'+Integer.toString(Integer.parseInt(t1)));
            txt7.setText(Cal_c);
            pg1.setMax(i);
            pg1.setProgress(i);
            textView2.setText("Total"+'\n'+Integer.toString(i));
            pg2.setMax(i);
            pg2.setProgress(Integer.parseInt(t));
            textView3.setText("Active"+'\n'+t);
            txt8.setText(Cal_a);
            pg3.setMax(i);
            pg3.setProgress(Integer.parseInt(t2));
            textView4.setText("Death"+'\n'+t2);
            txt9.setText(Cal_d);
            textView7.setText(t_m);

        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id  = item.getItemId();
        if (id == R.id.action_settings)
        {
            Intent intent = new Intent(MainActivity.this,setting.class);
            startActivity(intent);
        }
        if (id == R.id.action_feedback)
        {
            Intent intent = new Intent(MainActivity.this,Feedback.class);
            startActivity(intent);
        }
        if (id == R.id.action_use){
            Intent intent = new Intent(MainActivity.this,HU.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

}
