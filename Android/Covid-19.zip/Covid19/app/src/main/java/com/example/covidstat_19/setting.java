package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

@SuppressLint("Registered")
public class setting extends AppCompatActivity {
    ImageView linkedin1,linkedin2,linkedin3,linkedin4,linkedin5,mail1,mail2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        linkedin1 = findViewById(R.id.linkedin1);
        linkedin2 = findViewById(R.id.linkedin2);
        linkedin3 = findViewById(R.id.linkedin3);
        linkedin4 = findViewById(R.id.linkedin4);
        linkedin5 = findViewById(R.id.linkedin5);
        mail1 = findViewById(R.id.mail1);
        mail2 = findViewById(R.id.mail2);


    }

    @Override
    protected void onResume() {
        super.onResume();
        linkedin2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/sagar-singh-07b374168"));
                    setting.this.startActivity(webIntent);
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });


        linkedin3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/rohitash-kumar-00"));
                    setting.this.startActivity(webIntent);
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });

        linkedin1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/rohit-vardhani-4b0a74179"));
                    setting.this.startActivity(webIntent);
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });


        linkedin5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/yash-sharma-bab386186"));
                    setting.this.startActivity(webIntent);
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });
        linkedin4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.linkedin.com/in/yash-raj-mathur-434bb3183"));
                    setting.this.startActivity(webIntent);
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });
        mail1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Toast.makeText(setting.this,"Redirected to Gmail",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setType("message/rfc822");
                    intent.setData(Uri.parse("mailto:swatiopenhouse@gmail.com"));
                    startActivity(Intent.createChooser(intent,"Send mail...."));
                    Toast.makeText(setting.this,"Redirected to Gmail",Toast.LENGTH_SHORT).show();
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });
        mail2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Toast.makeText(setting.this,"Redirected to Gmail",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setType("message/rfc822");
                    intent.setData(Uri.parse("mailto:sagar.singh@protonmail.com"));
                    startActivity(Intent.createChooser(intent,"Send mail...."));
                } catch (ActivityNotFoundException ex) {
                    Toast.makeText(setting.this,"Please check Internet" +"\n" +"Connection and Restart app",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
