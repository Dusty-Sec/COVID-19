package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class dist extends AppCompatActivity {
    TextView textView_d, textView1_d, textView2_d, textView3_d, textView4_d, txt14_d, txt15_d,txt16_d,test;
    String tempholder1_d, tempholder2_d;
    AdView ad3;
    ProgressBar pg_d, pg1_d, pg2_d, pg3_d;
    int flag_d = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dist);
        tempholder1_d = getIntent().getStringExtra("state_name");
        tempholder2_d = getIntent().getStringExtra("district_name");
       if (!isNetworkAvailable()) {
            Toast.makeText(this, "Please check your Internet" + "\n" + "Connection and Restart app.", Toast.LENGTH_LONG).show();
        }
        textView_d = findViewById(R.id.textView_dis);
        textView1_d = findViewById(R.id.textView1_dis);
        textView2_d = findViewById(R.id.textView2_dis);
        test = findViewById(R.id.test);
        textView3_d = findViewById(R.id.textView3_dis);
        textView4_d = findViewById(R.id.textView4_dis);
        txt14_d = findViewById(R.id.textview22);
        txt15_d = findViewById(R.id.textView23);
        txt16_d = findViewById(R.id.textView24);
        pg_d = findViewById(R.id.progressBar_dis);
        pg1_d = findViewById(R.id.progressBar1_dis);
        pg2_d = findViewById(R.id.progressBar2_dis);
        pg3_d = findViewById(R.id.progressBar3_dis);
        ad3 = findViewById(R.id.ad3);
        new duct().execute();
        AdRequest adreq = new AdRequest.Builder().build();
        ad3.loadAd(adreq);
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }




    @SuppressLint("StaticFieldLeak")
    public class duct extends AsyncTask<Void, Void, Void> {
        Elements title3_d, title4_d,title2;

        String t_d, t1_d,t2_d,t3_d,t4_d,ti;

        @Override
        protected Void doInBackground(Void... params) {
            try {
                Document doc1 = Jsoup.connect("https://www.grainmart.in/news/covid-19-coronavirus-india-state-and-district-wise-tally/").get();
                title3_d = doc1.select("section#covid-19-table");
                title4_d = title3_d.select("div.skgm-districts");
                title2 = title4_d.select("div.skgm-td");
                ti = title2.html();
                for (int i = 0; i < (title2.size()); i+=5) {
                    /*
                    Element row = title2.get(i);
                    Elements colms = row.select("td");
                    String state_name = colms.get(1).text();
                    */
                    Element row11 = title2.get(i);
                    String state_name = row11.text();
                    if (tempholder2_d.equals(state_name)) {
                        t_d = state_name;
                        Element total = title2.get(i + 1);
                        String[] t = total.text().split("\\s");
                        t1_d = t[0];
                        Element active = title2.get(i + 3);
                        String[] a = active.text().split("\\s");
                        t2_d = a[0];
                        Element cured = title2.get(i + 2);
                        String[] c = cured.text().split("\\s");
                        t3_d = c[0];
                        Element demise = title2.get(i + 4);
                        String[] d = demise.text().split("\\s");
                        t4_d = d[0];
                        flag_d = 1;
                        break;
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            if (flag_d == 1) {
                int max = Integer.parseInt(t1_d);
                float cal_cd = (float)(Integer.parseInt(t3_d))* 100/Integer.parseInt(t1_d);
                String Cal_cd = String.format("%.2f",cal_cd) + "%";
                float cal_ad = (float)(Integer.parseInt(t2_d)) * 100 /Integer.parseInt(t1_d);
                String Cal_ad = String.format("%.2f",cal_ad) + "%";
                float cal_dd = (float)(Integer.parseInt(t4_d))* 100/Integer.parseInt(t1_d);
                String Cal_dd = String.format("%.2f",cal_dd) + "%";
                textView_d.setText(t_d);
                pg_d.setMax(max);
                pg_d.setProgress(Integer.parseInt(t3_d));
                textView1_d.setText("Cured" + '\n' + t3_d);
                txt14_d.setText(Cal_cd);
                pg1_d.setMax(max);
                pg1_d.setProgress(max);
                textView2_d.setText("Total" + '\n' + t1_d);
                pg2_d.setMax(max);
                pg2_d.setProgress(Integer.parseInt(t2_d));
                textView3_d.setText("Active" + '\n' + t2_d);
                txt15_d.setText(Cal_ad);
                pg3_d.setMax(max);
                pg3_d.setProgress(Integer.parseInt(t4_d));
                textView4_d.setText("Death" + '\n' + t4_d);
                txt16_d.setText(Cal_dd);

            } else {
                textView_d.setText(tempholder2_d);
                textView1_d.setText("Cured" + '\n' + "0");
                textView2_d.setText("Total" + '\n' + "0");
                textView3_d.setText("Active" + "\n" + "0");
                textView4_d.setText("Death" + "\n" + "0");
                test.setText(ti);
            }
        }

    }
}
