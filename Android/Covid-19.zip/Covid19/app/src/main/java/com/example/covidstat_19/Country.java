package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.math.BigInteger;

public class Country extends AppCompatActivity {
    String temp;
    AdView ad9;
    ProgressBar pg, pg1, pg2, pg3;
    TextView t1, t2, t3, t4, t5, t6, t7, t8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country);
        t1 = findViewById(R.id.textView1_c);
        t2 = findViewById(R.id.textView2_c);
        t3 = findViewById(R.id.textView3_c);
        t4 = findViewById(R.id.textView4_c);
        t8 = findViewById(R.id.textView_c);
        pg = findViewById(R.id.progressBar_c);
        pg1 = findViewById(R.id.progressBar1_c);
        pg2 = findViewById(R.id.progressBar2_c);
        pg3 = findViewById(R.id.progressBar3_c);
        t5 = findViewById(R.id.textView7_c);
        t6 = findViewById(R.id.textView17_c);
        t7 = findViewById(R.id.textView18_c);
        ad9 = findViewById(R.id.ad9);
        temp = getIntent().getStringExtra("name");
        t8.setText(temp);
        AsyncTask<Void, Void, Void> execute = new duit().execute();
        AdRequest adreq = new AdRequest.Builder().build();
        ad9.loadAd(adreq);
    }

    @SuppressLint("StaticFieldLeak")
    public class duit extends AsyncTask<Void, Void, Void> {
        String t_c, t_a, d, t_r;
        Elements e, e1, e2;

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Document doc = Jsoup.connect("https://en.wikipedia.org/wiki/Template:COVID-19_pandemic_data").get();
                e = doc.select("table#thetable");
                e1 = e.select("tbody");
                e2 = e1.select("tr");

                for (int i = 2; i <= 12; i++) {
                    Element e6 = e2.get(i);
                    t_c = e6.select("th").text();
                    if (t_c.contains("[")) {
                        int j = t_c.length();
                        t_c = t_c.substring(0, j - 3);
                    }
                    if (t_c.equals(temp)) {
                        t_a = e6.select("td").get(0).text();
                        d = e6.select("td").get(1).text();
                        t_r = e6.select("td").get(2).text();
                    }

                }


            } catch (IOException ex) {
                ex.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

                t_a = t_a.replaceAll(",", "");
                t_r = t_r.replaceAll(",", "");
                d = d.replaceAll(",", "");
            if (!(t_r.equalsIgnoreCase("No Data") || d.equalsIgnoreCase("No Data") || t_a.equalsIgnoreCase("No Data"))) {
                BigInteger sum = new BigInteger(t_a).subtract(new BigInteger(t_r)).subtract(new BigInteger(d));
                int i = sum.intValue() / 1000;
                int j = new BigInteger(t_a).intValue() / 1000;
                int k = new BigInteger(t_r).intValue() / 1000;
                int l = new BigInteger(d).intValue() / 1000;
                float cal_c = (float) (k) * 100 / j;
                String Cal_c = String.format("%.2f", cal_c) + "%";
                float cal_a = (float) (i) * 100 / j;
                String Cal_a = String.format("%.2f", cal_a) + "%";
                float cal_d = (float) (l) * 100 / j;
                String Cal_d = String.format("%.2f", cal_d) + "%";
                pg.setMax(j);
                pg.setProgress(k);
                pg1.setMax(j);
                pg1.setProgress(j);
                pg2.setMax(j);
                pg2.setProgress(i);
                pg3.setMax(j);

                pg3.setProgress(l);
                t5.setText(Cal_c);
                t6.setText(Cal_a);
                t7.setText(Cal_d);
                t1.setText("Cured" + '\n' + t_r);
                t2.setText("Total" + "\n" + t_a);
                t3.setText("Active" + "\n" + sum.toString());
                t4.setText("Death" + "\n" + d);
            }
            else{
                int j = new BigInteger(t_a).intValue() / 1000;
                int l = new BigInteger(d).intValue() / 1000;
                float cal_d = (float) (l) * 100 / j;
                String Cal_d = String.format("%.2f", cal_d) + "%";
                pg1.setMax(j);
                pg1.setProgress(j);
                pg3.setMax(j);
                pg3.setProgress(l);
                t7.setText(Cal_d);
                t1.setText("Cured" + '\n' + "No Data");
                t2.setText("Total" + "\n" + t_a);
                t3.setText("Active" + "\n" + "No Data");
                t4.setText("Death" + "\n" + d);
            }
        }
    }
}
