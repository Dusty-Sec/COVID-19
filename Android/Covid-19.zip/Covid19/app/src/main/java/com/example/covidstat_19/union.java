package com.example.covidstat_19;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class union extends AppCompatActivity {
    ImageView imageView;
    AdView ad6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_union);
        imageView = findViewById(R.id.youtube);
        ad6 = findViewById(R.id.ad6);
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (!isNetworkAvailable())
        {
            Toast.makeText(this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
        }
        else
        {
            AdRequest adreq = new AdRequest.Builder().build();
            ad6.loadAd(adreq);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    try {
                         Intent webIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://youtu.be/3wZe95Fg8-M"));
                        union.this.startActivity(webIntent);
                    } catch (ActivityNotFoundException ex) {
                        Toast.makeText(union.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();
                    }
                }
            });
        }


    }
    private boolean isNetworkAvailable()
    {
        ConnectivityManager connectivityManager
                = (ConnectivityManager)  getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
