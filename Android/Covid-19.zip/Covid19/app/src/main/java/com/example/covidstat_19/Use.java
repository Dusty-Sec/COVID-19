package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Use extends AppCompatActivity {
    TextView txt;
    Button pre,next;
    int Count;
    ImageView img1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_use);
        txt = findViewById(R.id.textView19);
        pre = findViewById(R.id.button);
        next = findViewById(R.id.button2);
        img1 = findViewById(R.id.imageView9);
        if(Count == 0) {
            pre.setVisibility(View.INVISIBLE);
            txt.setText("Click on Menu");
            img1.setImageResource(R.drawable.ss1);
        }
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pre.setVisibility(View.VISIBLE);
                if(Count == 0){
                    Count+=1;
                    txt.setText("Click on State or UT");
                    img1.setImageResource(R.drawable.ss2);
                }
                else
                    if(Count == 1){
                        Count+=1;
                        txt.setText("Choose state or UT");
                        img1.setImageResource(R.drawable.ss3);
                    }
                 else
                     if(Count == 2){
                         Count+=1;
                         txt.setText("Click for Districts");
                         img1.setImageResource(R.drawable.ss4);
                     }
                  else
                     {

                         txt.setText("Your district data");
                         next.setVisibility(View.INVISIBLE);
                         img1.setImageResource(R.drawable.ss5);
                     }
            }
        });
        pre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next.setVisibility(View.VISIBLE);
                if (Count == 3){
                    txt.setText("Click for districts");
                    img1.setImageResource(R.drawable.ss4);
                    Count-=1;

                }
                else
                    if(Count == 2){
                        txt.setText("Choose State/UT");
                        img1.setImageResource(R.drawable.ss3);
                        Count-=1;
                    }
                else
                    if(Count == 1){
                        txt.setText("Click on State or UT");
                        img1.setImageResource(R.drawable.ss2);
                        Count-=1;
                    }
                 else  {
                     txt.setText("Click on Menu");
                     pre.setVisibility(View.INVISIBLE);
                        img1.setImageResource(R.drawable.ss1);
                    }
            }
        });


    }


}
