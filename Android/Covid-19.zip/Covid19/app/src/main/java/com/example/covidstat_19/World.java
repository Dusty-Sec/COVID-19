package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.math.BigInteger;
import java.util.ArrayList;

public class World extends AppCompatActivity {
    TextView t1,t2,t3,t4,t5,t6,t7,t8;
    String temp;
    ProgressBar pg,pg1,pg2,pg3;
    Spinner spinner6;
    ArrayAdapter<String> dis1;
    ArrayList<String> list1 ;
    private InterstitialAd minter;
    AdView ad8;
    int count1 =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_world);
        temp = getIntent().getStringExtra("Listclick");
        spinner6 = findViewById(R.id.spinner6);
        t1 = findViewById(R.id.textView1_w);
        t2 = findViewById(R.id.textView2_w);
        t3 = findViewById(R.id.textView3_w);
        t4 = findViewById(R.id.textView4_w);

        pg =  findViewById(R.id.progressBar_w);
        pg1 = findViewById(R.id.progressBar1_w);
        pg2 =  findViewById(R.id.progressBar2_w);
        pg3 =  findViewById(R.id.progressBar3_w);
        t5 = findViewById(R.id.textView7_w);
        t6 = findViewById(R.id.textView17_w);
        t7 = findViewById(R.id.textView18_w);
        ad8 =findViewById(R.id.ad8);
        MobileAds.initialize(World.this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {

            }
        });
        minter = new InterstitialAd(World.this);
        minter.setAdUnitId("ca-app-pub-5400102354887853/5985367074");

    }
    @SuppressLint("StaticFieldLeak")
    public class duit extends AsyncTask<Void, Void, Void> {
        String t_c,t_a,t_d,t_r;
        Elements e,e1,e2,e3,e4,e5;
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                Document doc = Jsoup.connect("https://en.wikipedia.org/wiki/Template:COVID-19_pandemic_data").get();
                e = doc.select("table#thetable");
                e1 = e.select("tbody");

                e2 = e1.select("tr.sorttop");
                e3 = e2.select("th");
                t_r =e3.get(4).text();
                t_d = e3.get(3).text();
                t_c = e3.get(2).text();
                e4= e1.select("tr");

                e5 = e4.select("th");
                int k = 12;
                while(k<=32){
                    t_a = e5.get(k).text();
                    if(t_a.contains("["))
                    {
                        int j = t_a.length();
                        t_a = t_a.substring(0,j-3);
                    }
                    if(!t_a.equals("India")) {
                        list1.add(t_a);
                    }
                    k=k+2;

                }
                dis1.notifyDataSetChanged();



            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;

        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
          //  t1.setText(t_c);
            t_c = t_c.replaceAll(",","");
            t_r = t_r.replaceAll(",","");
            t_d = t_d.replaceAll(",","");
            BigInteger sum = new BigInteger(t_c).subtract(new BigInteger(t_r)).subtract(new BigInteger(t_d)) ;
            int i = sum.intValue()/10000;
            int j = new BigInteger(t_c).intValue()/10000;
            int k = new BigInteger(t_r).intValue()/10000;
            int l = new BigInteger(t_d).intValue()/10000;
            float cal_c = (float)(k)* 100/j;
            String Cal_c = String.format("%.2f",cal_c) + "%";
            float cal_a = (float)(i) * 100 /j;
            String Cal_a = String.format("%.2f",cal_a) + "%";
            float cal_d = (float)(l)* 100/j;
            String Cal_d = String.format("%.2f",cal_d) + "%";
            pg.setMax(j);
            pg.setProgress(k);
            pg1.setMax(j);
            pg1.setProgress(j);
            pg2.setMax(j);
            pg2.setProgress(i);
            pg3.setMax(j);

            pg3.setProgress(l);
            t5.setText(Cal_c);
            t6.setText(Cal_a);
            t7.setText(Cal_d);
            t1.setText("Cured" + '\n' + t_r);
            t2.setText("Total" + "\n" + t_c);
            t3.setText("Active" + "\n" +  sum.toString());
            t4.setText("Death" + "\n" + t_d);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(count1!=0){
            Toast.makeText(this, "Please wait for a while to choose another", Toast.LENGTH_SHORT).show();
        }
        count1+=1;
        AsyncTask<Void, Void, Void> execute = new duit().execute();
        AdRequest adreq = new AdRequest.Builder().build();
        ad8.loadAd(adreq);
        minter.loadAd(new AdRequest.Builder().build());

        list1 = new ArrayList<String>();
        dis1 = new ArrayAdapter<String>(this, R.layout.spinner_item, list1);
        dis1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner6.setAdapter(dis1);
        spinner6.setPrompt("Choose Country(Excluding India)");
        spinner6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                if(minter.isLoaded()){
                    minter.show();
                }
                else {
                    Intent intent1 = new Intent(World.this, Country.class);
                    intent1.putExtra("name", list1.get(position));
                    startActivity(intent1);
                }
                minter.setAdListener(new AdListener(){

                    @Override
                    public void onAdClosed() {
                        super.onAdClosed();
                        gotoCountry();
                    }

                    private void gotoCountry() {
                        Intent intent1 = new Intent(World.this, Country.class);
                        intent1.putExtra("name", list1.get(position));
                        startActivity(intent1);
                    }
                });


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
