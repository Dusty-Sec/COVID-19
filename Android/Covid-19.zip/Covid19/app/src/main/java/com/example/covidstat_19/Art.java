package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.IOException;

public class Art extends AppCompatActivity {
    String a_ct,a_jpg,a_title;
    TextView ct,jpg,art;
    AdView ad2;
    ImageView img,img1;
    int flag = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_art);
        a_ct = getIntent().getStringExtra("newsa");
        a_jpg = getIntent().getStringExtra("newsas");
        a_title = getIntent().getStringExtra("newsasa");
        ct = findViewById(R.id.a_ct);
        art = findViewById(R.id.art);
        img1 = findViewById(R.id.imageView7);
        img = findViewById(R.id.i_jpg);
        ct.setText(a_title);
        ad2 = findViewById(R.id.ad2);
        if (isNetworkAvailable()) {
            AsyncTask<Void, Void, Void> execute = new duit().execute();
            AdRequest adreq = new AdRequest.Builder().build();
            ad2.loadAd(adreq);
        }
        else{
            Toast.makeText(Art.this,"Please check your Internet"+"\n"+"Connection and Restart app",Toast.LENGTH_LONG).show();

        }

    }

    private boolean isNetworkAvailable()
    {

        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        assert connectivityManager != null;
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();

    }

    @Override
    protected void onResume() {
        super.onResume();
        img1.setOnClickListener(new View.OnClickListener() {
            PackageManager pm = Art.this.getPackageManager();
            @Override
            public void onClick(View v) {
                try {

                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    PackageInfo info = pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);
                    intent.setPackage("com.whatsapp");
                    String a = a_title.replaceAll("\n","*");
                    intent.putExtra(Intent.EXTRA_TEXT, a_ct +"\n\n" + a +  "\n\n To stay updated for news and corona stats \n Download the Covid-19 app from below link:\n https://bit.ly/Covid-19-apk");
                    startActivity(Intent.createChooser(intent, "Share with"));
                }
                catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                    Toast.makeText(Art.this,"Whatsapp not installed",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @SuppressLint("StaticFieldLeak")
    public class duit extends AsyncTask<Void, Void, Void> {
        Document doc;
        String t;
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                doc = Jsoup.connect(a_ct).get();
                t = doc.select("div._1_AkB.clearfix").first().text();
                flag =1;

            } catch (Exception e) {
                e.printStackTrace();

                t = doc.select("arttextxml").first().text();
                Toast.makeText(Art.this,"Content not Available",Toast.LENGTH_SHORT).show();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            Picasso.get().load(a_jpg).error(R.drawable.na).into(img);
            if(flag == 1) {
                art.setText(t);
            }
            else{
                art.setText(t);
            }
        }
    }

}

