package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Use_1 extends AppCompatActivity {
    int Count =0;
    Button pre_1,next_1;
    TextView txt;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_use_1);
        pre_1 = findViewById(R.id.button_1);
        next_1 = findViewById(R.id.button_2);
        txt = findViewById(R.id.textView20);
        img = findViewById(R.id.imageView10);
        if(Count == 0) {
            pre_1.setVisibility(View.INVISIBLE);
            txt.setText("Click on Menu");
            img.setImageResource(R.drawable.ss1);
        }
        next_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pre_1.setVisibility(View.VISIBLE);
                if(Count == 0){
                    Count+=1;
                    txt.setText("Click on News");
                    img.setImageResource(R.drawable.ss6);

                }
                else
                if(Count == 1){
                    Count+=1;
                    txt.setText("Choose state or UT");
                    img.setImageResource(R.drawable.ss7);
                }
                else
                if(Count == 2){
                    Count+=1;
                    txt.setText("Click on news");
                    img.setImageResource(R.drawable.ss8);
                }
                else
                {

                    txt.setText("Click to share news");
                    img.setImageResource(R.drawable.ss9);
                    next_1.setVisibility(View.INVISIBLE);
                }
            }
        });
        pre_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                next_1.setVisibility(View.VISIBLE);
                if (Count == 3){
                    txt.setText("Click on news");
                    img.setImageResource(R.drawable.ss8);
                    Count-=1;

                }
                else
                if(Count == 2){
                    txt.setText("Choose State/UT");
                    img.setImageResource(R.drawable.ss7);
                    Count-=1;
                }
                else
                if(Count == 1){
                    txt.setText("Click on News");
                    Count-=1;
                    img.setImageResource(R.drawable.ss6);
                }
                else  {
                    txt.setText("Click on Menu");
                    pre_1.setVisibility(View.INVISIBLE);
                    img.setImageResource(R.drawable.ss1);
                }
            }
        });
    }
}
