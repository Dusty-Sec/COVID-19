package com.example.covidstat_19;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

public class Feedback extends AppCompatActivity {
    AdView ad4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        Button btn = findViewById(R.id.btn);
        ad4 = findViewById(R.id.ad4);
        AdRequest adreq = new AdRequest.Builder().build();
        ad4.loadAd(adreq);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText t = findViewById(R.id.subject);
                EditText t1 = findViewById(R.id.message1);
                String s1 = t1.getText().toString();
                String s = t.getText().toString();

                if(s.length() == 0 ){
                    Toast.makeText(Feedback.this,"Subject field is empty",Toast.LENGTH_SHORT).show();
                }
                if(s1.length() == 0 ){
                    Toast.makeText(Feedback.this,"Body field is empty",Toast.LENGTH_SHORT).show();
                }
                if(s.length()!= 0 && s1.length()!= 0){
                    Toast.makeText(Feedback.this, "Redirected to Gmail", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Intent.ACTION_SENDTO);
                    intent.setType("message/rfc822");
                    intent.setData(Uri.parse("mailto:swatiopenhouse@gmail.com"));
                    intent.putExtra(Intent.EXTRA_SUBJECT, s);
                    intent.putExtra(Intent.EXTRA_TEXT , s1);
                    startActivity(Intent.createChooser(intent,"Send mail...."));
                    t.setText("");
                    s= "";
                    s1 ="";
                    t1.setText("");
                }
            }
        });
    }
}

